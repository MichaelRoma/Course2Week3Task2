//
//  TableViewCellMy.swift
//  Course2Week3Task2
//
//  Created by Mykhailo Romanovskyi on 28.01.2020.
//  Copyright © 2020 e-Legion. All rights reserved.
//

import UIKit

class TableViewCellMy: UITableViewCell {
    @IBOutlet weak var imageViewCell: UIImageView!
    @IBOutlet weak var uiLabelCell: UILabel!
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    func setPhotoCell(_ photo: Photo) {
        accessoryType = .detailButton
      imageViewCell.image = photo.image
      uiLabelCell.text = photo.name
    }
 
    
}
