//
//  CollectionViewController.swift
//  Course2Week3Task2
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController {
    let cellIdentifier = "MyCell"
    let nibNameForCell = "PhotoCollectionViewCell"
    @IBOutlet weak var myPhotoCollection: UICollectionView!
    var customFlowLayout =  CustomFlowLayout()
    var photosTest: [Photo] = []

    override func viewDidLoad() {
        super.viewDidLoad()

     //   myPhotoCollection.backgroundColor = .blue
        photosTest = PhotoProvider().photos()
        myPhotoCollection.dataSource = self
        myPhotoCollection.delegate = self
        
        let nib = UINib(nibName: nibNameForCell, bundle: nil)
        myPhotoCollection.register(nib, forCellWithReuseIdentifier: cellIdentifier)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        myPhotoCollection.setCollectionViewLayout(customFlowLayout, animated: true)
    }
}

extension CollectionViewController: UICollectionViewDataSource, UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photosTest.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = myPhotoCollection.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! PhotoCollectionViewCell

        cell.configure(with: photosTest[indexPath.item])
        return cell
    }
}
